---
title: "Projects"
hero_image: "hero.jpg"
nometadata: true
notags: true
noshare: true
nocomments: true
---

<h2>Minimal Academic</h2>
This site, written using Hugo and inspired by <a href="https://sourcethemes.com/academic/">Academic</a> and <a href="https://mmistakes.github.io/minimal-mistakes/">Minimal Mistakes</a>.