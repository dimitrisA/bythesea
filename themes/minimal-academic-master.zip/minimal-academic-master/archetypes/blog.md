---
title: "{{ replace .Name "-" " " | title }}"
hero_image: "hero.jpg"
date: {{ .Date }}
description: "Description"
draft: true
---

## Header